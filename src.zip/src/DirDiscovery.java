public class DirDiscovery {

    public DirDiscovery(){

    }

    public static String getDir(){
        return null;
    }
}
