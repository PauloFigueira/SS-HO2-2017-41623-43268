package Exceptions;

public class LoggedInAccountException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoggedInAccountException() {
        super();
    }
}
